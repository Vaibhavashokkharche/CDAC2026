import { BrowserRouter, Routes, Route } from "react-router-dom";

import ProductList from "./component/ProductList";
import ProductForm from "./component/ProductForm";
import ProductEdit from "./component/ProductEdit";

function App() {

  return (

    <BrowserRouter>

      <Routes>

        <Route
          path="/list"
          element={<ProductList/>}
        />

        <Route
          path="/add"
          element={<ProductForm />}
        />

        <Route
    path="/edit/:pid"
    element={<ProductEdit />}
/>

      </Routes>

    </BrowserRouter>

  );
}

export default App;