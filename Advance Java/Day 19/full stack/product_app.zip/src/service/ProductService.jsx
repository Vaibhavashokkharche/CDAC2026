import axios from "axios";
var BASE_URL="http://localhost:8484/product"
class ProductService{
    getAllProducts(){
        let url=BASE_URL+"/products"
        return axios.get(url);
    }
    getProductById(pid) {
        return axios.get(`${BASE_URL}/products/${pid}`);
    }

    saveProduct(product) {
        return axios.post(
            `${BASE_URL}/products/${product.pid}`,
            product,
            {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            }
        );
    }

    updateProduct(formData) {
        return axios.put(
            `${BASE_URL}/products/${formData.pid}`,
            formData,
            {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            }
        );
    }

    deleteProduct(pid) {
        return axios.delete(`${BASE_URL}/products/${pid}`);
    }

    getProductsByPrice(lowPrice, highPrice) {
        return axios.get(
            `${BASE_URL}/products/${lowPrice}/${highPrice}`
        );
    }

    getImageUrl(filename) {
        return `${BASE_URL}/image/${filename}`;
    }
   /* getImageUrl(filename) {
        return `${baseUrl}/image/${filename}`;
    }*/
}
export default new ProductService();