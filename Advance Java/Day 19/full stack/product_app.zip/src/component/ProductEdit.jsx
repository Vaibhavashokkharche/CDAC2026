import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import ProductService from "../service/ProductService";

function ProductEdit() {

    const params = useParams();
    const navigate = useNavigate();

    const [product, setProduct] = useState({
        pid: "",
        pname: "",
        qty: "",
        price: "",
        mfgdate:"",
        cid:""
    });

    const [image, setImage] = useState(null);

    useEffect(() => {
        loadProduct();
    }, []);

    const loadProduct = () => {

        ProductService.getProductById(params.pid)
            .then((response) => {

                setProduct(response.data);

            })
            .catch((error) => {
                console.log(error);
            });
    };

    const handleChange = (e) => {

        setProduct({
            ...product,
            [e.target.name]: e.target.value
        });
    };

    const handleFileChange = (e) => {
        setImage(e.target.files[0]);
    };

    const updateProduct = (e) => {

        e.preventDefault();

        let formData = new FormData();

        formData.append("pid", product.pid);
        formData.append("pname", product.pname);
        formData.append("qty", product.qty);
        formData.append("price", product.price);
        formData.append("mfgdate", product.mfgdate);
        formData.append("cid", product.cid);

        if (image !== null) {
            formData.append("image", image);
        }

        ProductService.updateProduct(formData)
            .then(() => {

                alert("Product Updated");
                navigate("/list");

            })
            .catch((error) => {
                console.log(error);
            });
    };

    return (
        <div className="container">

            <h2>Edit Product</h2>

            <form onSubmit={updateProduct}>

                <div>
                    Product Id
                    <input
                        type="text"
                        name="pid"
                        value={product.pid}
                        readOnly
                    />
                </div>

                <br />

                <div>
                    Product Name
                    <input
                        type="text"
                        name="pname"
                        value={product.pname}
                        onChange={handleChange}
                    />
                </div>

                <br />

                <div>
                    Quantity
                    <input
                        type="number"
                        name="qty"
                        value={product.qty}
                        onChange={handleChange}
                    />
                </div>

                <br />

                <div>
                    Price
                    <input
                        type="number"
                        name="price"
                        value={product.price}
                        onChange={handleChange}
                    />
                </div>
                <br/>
                <div>
                    mfgdate
                    <input
                        type="date"
                        name="mfgdate"
                        value={product.mfgdate}
                        onChange={handleChange}
                    />
                </div>

                <br />
<div>
                    cid
                    <input
                        type="number"
                        name="cid"
                        value={product.cid}
                        onChange={handleChange}
                    />
                </div>
                <br/>

                <div>
                    Current Image
                    <br />

                    {product.pimagefile && (
                        <img
                            src={ProductService.getImageUrl(product.pimagefile)}
                            alt=""
                            width="150"
                        />
                    )}
                </div>

                <br />

                <div>
                    Select New Image
                    <input
                        type="file"
                        onChange={handleFileChange}
                    />
                </div>

                <br />

                <button type="submit">
                    Update Product
                </button>

            </form>

        </div>
    );
}

export default ProductEdit;