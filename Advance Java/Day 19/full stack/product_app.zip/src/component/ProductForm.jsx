import React, { useState } from "react";
import ProductService from "../service/ProductService";
import { useNavigate } from "react-router-dom";

function ProductForm() {
    const navigate=useNavigate
    const [product, setProduct] = useState({
        pid: "",
        pname: "",
        qty: "",
        price: "",
        mfgdate:""
    });

    const [image, setImage] = useState(null);

    const handleChange = (e) => {
        setProduct({
            ...product,
            [e.target.name]: e.target.value
        });
    };

    const handleFileChange = (e) => {
        setImage(e.target.files[0]);
    };

    const saveProduct = (e) => {

        e.preventDefault();

        let formData = new FormData();

        formData.append("pid", product.pid);
        formData.append("pname", product.pname);
        formData.append("qty", product.qty);
        formData.append("price", product.price);
        formData.append("mfgdate",product.mfgdate)
        formData.append("image", image);
        formData.append("cid", 1);

        ProductService.saveProduct(formData)
            .then((response) => {
                console.log(response.data);
                alert("Product Saved");
                navigate("/list");
            })
            .catch((error) => {
                console.log(error);
            });
    };

    return (
        <div>

            <h2>Add Product</h2>

            <form onSubmit={saveProduct}>

                <div>
                    Product Id :
                    <input
                        type="text"
                        name="pid"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    Product Name :
                    <input
                        type="text"
                        name="pname"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    Qty :
                    <input
                        type="text"
                        name="qty"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    Price :
                    <input
                        type="text"
                        name="price"
                        onChange={handleChange}
                    />
                </div>
                <div>
                    MfgDate :
                    <input
                        type="date"
                        name="mfgdate"
                        onChange={handleChange}
                    />
                </div>
                <div>
                    Image :
                    <input
                        type="file"
                        onChange={handleFileChange}
                    />
                </div>

                <button type="submit">
                    Save Product
                </button>

            </form>

        </div>
    );
}

export default ProductForm;