import {useState,useEffect} from 'react';
import ProductService from '../service/ProductService'
import {Link} from 'react-router-dom';
function ProductList(){
  const [products,setProducts]=useState([]);
  //initialization of product array to get data from web service

  useEffect(()=>{
    loadProducts();
  },[])
  const deleteProduct=async (pid)=>{
    console.log("in delete product"+pid);
    var response=await ProductService.deleteProduct(pid)
    if(response.status==200 && response.ok){
         console.log(response.data);
         loadProducts();
    }

  }
  
  const loadProducts=()=>{
    ProductService.getAllProducts()
    .then((response)=>{
        console.log(response.data)
        setProducts(response.data)})
    .catch((err)=>{console.log(err)})
  }
   return (
        <div className="container">

            <h2>Product List</h2>

            <table border="1">

                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    {products.map((p) => (
                        <tr key={p.pid}>

                            <td>{p.pid}</td>
                            <td>{p.pname}</td>
                            <td>{p.qty}</td>
                            <td>{p.price}</td>

                            <td>
                                <img
                                    src={
                                        p.imageUrl
                                        
                                    }
                                    width="100"
                                    alt=""
                                />
                            </td>

                            <td>
                                <button
                                    onClick={() =>
                                        deleteProduct(p.pid)
                                    }
                                >
                                    Delete
                                </button> &nbsp;&nbsp;&nbsp;
                                <Link to={`/edit/${p.pid}`}>
                                <button>
                                    
                                    
                                
                                    edit
                                </button></Link>
                            </td>

                        </tr>
                    ))}
                </tbody>

            </table>

        </div>
    );
}
export default ProductList;